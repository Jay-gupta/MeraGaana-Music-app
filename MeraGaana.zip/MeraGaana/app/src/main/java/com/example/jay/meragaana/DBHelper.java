package com.example.jay.meragaana;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase sql;
    public DBHelper(Context context) {
        super(context, "PlaylistDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

     //   String query = "Create table MyPlaylist(rowid INTEGER PRIMARY KEY AUTOINCREMENT,title text)";
     //   db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insert(String title){
        sql = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        sql.insert("MyPlaylist", null, contentValues);
    }
}
