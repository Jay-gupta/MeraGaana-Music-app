package com.example.jay.meragaana;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class Playlist extends AppCompatActivity {

    EditText title;
    Button insert, fetch;
    ListView listView;
    DBHelper dbDemo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        title= findViewById(R.id.editText);
        insert = findViewById(R.id.insert);
        fetch = findViewById(R.id.fetch);
        listView=  findViewById(R.id.lv);


        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = title.getText().toString().trim();
                dbDemo.insert(t);

                Toast.makeText(Playlist.this, "Data inserted Successfully", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
