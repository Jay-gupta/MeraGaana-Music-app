package com.example.jay.meragaana;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class Home extends AppCompatActivity {

    EditText username1;
    EditText password1;
    Button loginButton;
    CheckBox rememberMeCheckBox;
    String username, password;
    SharedPreferences sh_users;


    public void login(){
        username  = username1.getText().toString().trim();
        password = password1.getText().toString().trim();
        if(rememberMeCheckBox.isChecked()) {
            sh_users.edit().putString("key_username", username).commit();
            sh_users.edit().putString("key_password", password).commit();
            finish();
            startActivity(new Intent(this, Player.class));
        }else{
            finish();
            startActivity(new Intent(this, Player.class));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        username1 = findViewById(R.id.username1);
        password1 = findViewById(R.id.password1);
        loginButton = findViewById(R.id.loginButton);
        rememberMeCheckBox = findViewById(R.id.rememberMeCheckBox);

        sh_users = this.getSharedPreferences("com.example.hp.musicplayer", Context.MODE_PRIVATE);

        String current = sh_users.getString("key_username", null);

        if(current != null){
            finish();
            startActivity(new Intent(this, Player.class));
        }

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username1.getText().toString().trim().equals("") || password1.getText().toString().trim().equals("")) {
                    Toast.makeText(Home.this, "Enter Username and Password", Toast.LENGTH_SHORT).show();
                }else{
                    login();
                }
            }
        });

    }
}
